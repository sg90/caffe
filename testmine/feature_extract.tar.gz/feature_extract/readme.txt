./extract.py [input_imglist] [output_features]

Help:
./extract.py -h
